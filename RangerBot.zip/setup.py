import os
import sys
from setuptools import setup

import some_module


setup(
    name='pip_test',
    author='None',
    version='0.0.1',
    zip_safe=False,
    packages=['some_module']
)

